window.addEventListener("load", function () {
    var posalji = document.getElementById("posalji");
    posalji.addEventListener("click", function () {
        var obaveznaPolja = document.querySelectorAll('input[required]');
        var svaPoljaIspunjena = true;
        
                var ime = document.getElementById("ime").value;
                var prezime = document.getElementById("prezime").value;
                var email = document.getElementById("email").value;
                var telefon = document.getElementById("telefon").value;
                var broj_osoba = document.getElementById("broj_osoba").value;
                var datum_dolaska = document.getElementById("datum_dolaska").value;
                var datum_odlaska = document.getElementById("datum_odlaska").value;
                var dodatni_zahtjevi = document.getElementById("dodatni_zahtjevi").value;

                var upisRegex = (/^[a-zA-Z0-9]+$/);
        

        for (var i = 0; i < obaveznaPolja.length; i++) {
            if (obaveznaPolja[i].value === '') {
                svaPoljaIspunjena = false;
                break;
            }
        }
        if (svaPoljaIspunjena) {
            if ((!upisRegex.test(ime)) || (!upisRegex.test(prezime)) || (!upisRegex.test(email)) || (!upisRegex.test(telefon)) || (!upisRegex.test(broj_osoba)) || /*(!upisRegex.test(datum_dolaska)) || (!upisRegex.test(datum_odlaska)) ||*/ (!upisRegex.test(dodatni_zahtjevi))) {
                            event.preventDefault();
                            alert("Jedan od vaših upisanih podataka sadrži nedopuštene znakove!");
                            return false;
                        } else {
            return true;
            }
        } else {
            event.preventDefault();
            alert('Molimo ispunite sva obavezna polja.');
            return false;
        }
    });
});